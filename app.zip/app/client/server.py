import socket
import datetime
        
s = socket.socket()
s.bind((socket.gethostname(), 12346))
s.listen(5) 
while True:
    d, addr = s.accept() 
    data =d.recv(1024)
    if(data == "getdata"):
        d.send(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
    else:
        print("RECIEVED:" , data)
        d.send(data)
