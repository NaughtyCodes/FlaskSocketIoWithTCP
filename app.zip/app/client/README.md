# TCP_Client_Server
TCP client server connection example app in python
